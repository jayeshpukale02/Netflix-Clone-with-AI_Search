"""Mini Optimizer — candidate implementation.

Fill in the `optimize` function below. See README.md for the full spec.

You may add helper functions / classes / modules as needed, but the public
entry point `optimize(...)` must keep the exact signature and return shape
described in the README.
"""

from __future__ import annotations

import pandas as pd
import numpy as np


def optimize(
    trades_df: pd.DataFrame,
    stop_losses: list[float],
    take_profits: list[float],
    top_n: int = 5,
) -> list[dict]:
    """Return the top-N (stop_loss, take_profit) combinations by Sharpe.

    See README.md for:
      - input data schema (trade_id, entry_time, exit_time, pnl, mae, mfe)
      - SL/TP application rules (SL takes priority over TP)
      - Sharpe definition (mean / std, sharpe = 0.0 when degenerate)
      - required result dict keys
      - tie-breaking and deterministic ordering rules
      - edge cases you must handle
    """
    if trades_df.empty or not stop_losses or not take_profits:
        return []

    # Drop rows with NaN in pnl, mae, or mfe
    df = trades_df.dropna(subset=['pnl', 'mae', 'mfe'])
    if df.empty:
        return []

    pnl = df['pnl'].values
    mae = df['mae'].values
    mfe = df['mfe'].values

    results = []
    for sl in stop_losses:
        for tp in take_profits:
            sl_hit = mae >= sl
            tp_hit = (mfe >= tp) & (~sl_hit)
            
            adj_pnl = np.where(sl_hit, -sl, np.where(tp_hit, tp, pnl))
            
            std = np.std(adj_pnl, ddof=0)
            if np.isnan(std) or std == 0.0:
                sharpe = 0.0
            else:
                sharpe = np.mean(adj_pnl) / std
                
            results.append({
                "stop_loss": float(sl),
                "take_profit": float(tp),
                "sharpe": float(sharpe),
                "total_pnl": float(np.sum(adj_pnl)),
                "stopped_out": int(np.sum(sl_hit)),
                "took_profit": int(np.sum(tp_hit)),
            })

    results.sort(key=lambda x: (-x['sharpe'], -x['total_pnl'], x['stop_loss'], x['take_profit']))
    return results[:top_n]
