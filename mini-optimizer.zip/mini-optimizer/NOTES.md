# Mini Optimizer - Implementation Notes

## Approach Taken
I implemented a semi-vectorized grid search. The code iterates over the `(stop_loss, take_profit)` grid combinations using standard Python loops, but the core mathematical and logical evaluations for the trades within each iteration are fully vectorized using NumPy.

Why this approach? With a standard grid size of up to 32x32 (1024 combinations) and a dataset size around 5,000 trades, the amount of work per loop iteration is perfectly sized for 1D NumPy arrays. A fully vectorized 3D approach (using `numpy` broadcasting to evaluate all trades across all parameter pairs simultaneously) would require significantly more memory overhead and make the code much harder to read and debug. Looping 1024 times in Python while delegating the 5000-element operations to NumPy's compiled C backend is exceptionally fast (completing the full sweep in well under a second) while cleanly satisfying the performance constraint.

## Readability vs. Speed Tradeoffs
- **Trading Full 3D Vectorization for Readability:** I deliberately avoided full multi-dimensional array broadcasting. While marginally faster, operations like `mae[:, None, None] >= sl_grid[None, :, :]` are notoriously difficult for future maintainers to decipher.
- **Trading Pandas Convenience for Speed:** I traded the convenience of Pandas `Series` by extracting the underlying NumPy arrays (`pnl = df['pnl'].values`) before entering the nested loops. Pandas overhead inside tight loops is a major performance killer; using raw NumPy arrays ensures maximum performance.

## What I'd Do Differently With Another Day
If I had another day, I would focus on:
1.  **Smarter Search Algorithms:** For larger parameter grids (e.g., adding trailing stops or time-based exits), a naive grid search would become too slow. I would implement a coarse-to-fine grid search or integrate a more efficient optimization algorithm.
2.  **Extended Statistics:** I would add additional trading metrics alongside the Sharpe ratio, such as Maximum Drawdown, Win Rate, and Sortino Ratio, making the output richer for quantitative analysis.
3.  **Property-Based Testing:** I'd write a suite of tests using a library like `hypothesis` to fuzz the `optimize` function with thousands of random permutations of trades to mathematically prove invariants (e.g., that Stop-Loss is always respected strictly).
4.  **Memory Management:** For datasets significantly larger than 5,000 rows, I'd strictly downcast numeric types to `float32` and `int32` to halve memory consumption and improve CPU cache hit rates.
